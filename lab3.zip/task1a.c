#include <stdio.h>
#include <stdlib.h>

typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
}virus;

virus* readVirus(FILE* file){
    struct virus *nextVirus=(virus*)malloc(sizeof(virus));
    int x=fread(nextVirus,1,18,file);
    if(x==18){
        nextVirus->sig=(char*)malloc(nextVirus->SigSize);
        fread(nextVirus->sig,1,nextVirus->SigSize,file);
        return nextVirus;
    }
    return NULL;
}

void PrintHex(unsigned char *buffer, size_t length, FILE * outputFile){
    for(int i=0;i<length;i++)
        fprintf(outputFile,"%02X ",buffer[i]);  
}

void printVirus(virus* virus, FILE* outputFile){
    fprintf(outputFile,"Virus name: %s\n",virus->virusName);
    fprintf(outputFile,"Virus size: %d\n",virus->SigSize);
    fprintf(outputFile,"signature: \n");
    PrintHex(virus->sig,virus->SigSize,outputFile);
    fprintf(outputFile,"\n\n");
}

int main(int argc, char **argv) {
    FILE *inputFile;
    FILE *outputFile;
    struct virus * virus;
    inputFile=fopen("signatures","r");
    outputFile=fopen("lab3_out","w");
    if(inputFile && outputFile){
        while ((virus=readVirus(inputFile))!=NULL)
            printVirus(virus,outputFile);          
    }
    else
        fprintf(stderr,"ERROR: there is problem with some files");
    return 0;
}

