#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
}virus;

typedef struct link link; 
struct link {
    link *nextVirus;
    virus *vir;
};


 struct fun_desc {
  char *name;
  void (*fun)();
};

link * virLink;

virus* readVirus(FILE* file){
    virus *nextVirus=(virus*)malloc(sizeof(virus));
    int x=fread(nextVirus,1,18,file);
    if(x==18){
        nextVirus->sig=(unsigned char*)malloc(nextVirus->SigSize);
        fread(nextVirus->sig,1,nextVirus->SigSize,file);
        return nextVirus;
    }
    return NULL;
}
void PrintHex(unsigned char *buffer, size_t length, FILE * outputFile){
    for(int i=0;i<length;i++)
        fprintf(outputFile,"%02X ",buffer[i]);  
}
void printVirus(virus* virus, FILE* outputFile){
    fprintf(outputFile,"Virus name: %s\n",virus->virusName);
    fprintf(outputFile,"Virus size: %d\n",virus->SigSize);
    fprintf(outputFile,"signature: \n");
    PrintHex(virus->sig,virus->SigSize,outputFile);
    fprintf(outputFile,"\n\n");
}

/* Print the data of every link in list to the given stream. Each item followed by a newline character. */
void list_print(link *virus_list, FILE* outputFile){
    link *temp=virus_list;
    while(temp!=NULL && temp->vir!=NULL){
        printVirus(temp->vir,outputFile);
        temp=temp->nextVirus;
    }
}
 
 /* Add a new link with the given data to the list 
 (either at the end or the beginning, depending on what your TA tells you),
 and return a pointer to the list (i.e., the first link in the list).
 If the list is null - create a new entry and return a pointer to the entry. */
 link* list_append(link* virus_list, virus* data){
    link *newLink=(link*)malloc(sizeof(link));
    newLink->vir=data;
    newLink->nextVirus=NULL;
    if(virus_list->vir==NULL)
        return newLink;
    link *help=virus_list;
    while (help->nextVirus!=NULL)
        help=help->nextVirus;
    help->nextVirus=newLink;
    return virus_list;
 }

/* Free the memory allocated by the list. */ 
void list_free(link *virus_list){
    while(virus_list!=NULL && virus_list->vir!=NULL)
    {
        free(virus_list->vir->sig);
        free(virus_list->vir);
        virus_list=virus_list->nextVirus;
    }
    virLink=NULL;
}

/* Gets a char c,  and if the char is 'q' , ends the program with exit code 0. Otherwise returns c. */
 void quit(){
     list_free(virLink);
     exit(0);
     }
 
void LoadSignatures(){
    FILE *inputFile;
    virus * virus;
    char word[128];
    fgets(word, 128, stdin);
    word[strcspn(word, "\n")] = '\0';
    fseek(stdin,0,SEEK_END);//for clean the buffer
    inputFile=fopen(word,"r");
    if (inputFile)
    {      
        while ((virus=readVirus(inputFile))!=NULL)
            virLink=list_append(virLink,virus);
        fclose(inputFile);
    }
    else
        fprintf(stderr,"ERROR: There is no file with this name\n");
 }

 void PrintSignatures(){
    if(virLink!=NULL)
        list_print(virLink,stdout);
 }

void detect_virus(char *buffer, unsigned int size, link *virus_list){
    link* help=virus_list;
    while (help!=NULL && help->vir!=NULL)
    {
        for(int i=0;i<size;i++){
            unsigned short sigSize=help->vir->SigSize;
            char subbuff[sigSize+1];
            memcpy( subbuff, &buffer[i], sigSize );
            subbuff[sigSize] = '\0';
            if(memcmp(subbuff,help->vir->sig,sigSize)==0){
                fprintf(stdout,"\nThe starting byte location is: %d\n",i);
                fprintf(stdout,"Virus name: %s\n",help->vir->virusName);
                fprintf(stdout,"Virus size: %d\n",help->vir->SigSize);
                fprintf(stdout,"\n");
            }
        }
        help=help->nextVirus;
    }
    
}

void DetectViruses(){
    FILE *inputFile;
    char buffer[10000];
    char word[128];
    fgets(word, 128, stdin);
    word[strcspn(word, "\n")] = '\0';
    fseek(stdin,0,SEEK_END);//for clean the buffer
    inputFile=fopen(word,"r");
    if (inputFile)
    {   
        size_t len = fread(buffer,1,10000,inputFile);
        detect_virus(buffer,len,virLink);
        fclose(inputFile);
    }
    else
        fprintf(stderr,"ERROR: There is no file with this name\n");
}


struct fun_desc menu[] =
        {{ "Load signatures", LoadSignatures}, { "Print signatures", PrintSignatures },{"Detect viruses", DetectViruses },{ "Quit", quit }, { NULL, NULL } };

int main(int argc, char **argv){
    int i=0;
	int option=0;
	int bound=(sizeof(menu)/sizeof(menu[0]))-1;
    virLink=(link*)malloc(sizeof(link));
    while(1)
	{
		i=0;
		printf("Please choose a function:\n");
		while(menu[i].name){
			printf("%d) %s\n",i+1,menu[i].name);
			i++;
		}
        fseek(stdin,0,SEEK_END);//for clean the buffer
		printf("Option: ");
		scanf("%d",&option);
		if(option>=1 && option <=bound)
			printf("Within bounds\n");
		else{
			printf("Not within bounds\n");
			quit();
		}
        fgetc(stdin);
		menu[option-1].fun();
	}
    return 0;
}