#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <zconf.h>
#include <sys/mman.h>
#include <elf.h>

struct fun_desc {
    char *name;

    void (*fun)();
};

void *map;
int currentFD;
int debug_mode;

void toogleDebugMode() {
    debug_mode = 1 - debug_mode;
}

void examineELFFile() {
    char buffer[100];
    printf("enter ELF file name\n");
    fgets(buffer, 100, stdin);
    size_t ln = strlen(buffer) - 1;
    if (buffer[ln] == '\n')
        buffer[ln] = '\0';
    if (currentFD != -1)
        close(currentFD);
    int fd = open(buffer, O_RDONLY);
    currentFD = fd;
    map = mmap(NULL, lseek(currentFD, 0, SEEK_END), PROT_READ, MAP_SHARED, currentFD, 0);
    lseek(currentFD, 0, SEEK_SET);
    if (map == (void *) -1) {
        printf("ERROR\n");
        return;
    }
    char *a = (char *) map;
    if (*(a + 1) != 'E' || *(a + 2) != 'L' || *(a + 3) != 'F') {
        printf("not an ELF file\n");
        return;
    }
    printf("1. Magic number first 3 bytes are: %c%c%c \n", *(a + 1), *(a + 2), *(a + 3));
    if (*(a + 5) == 1)
        printf("2. Data encoding: Little Endian\n");
    else
        printf("2. Data encoding: Big Endian\n");
    printf("3. Entry point is: %X\n", *((int *) (a + 24)));
    printf("4. File offset of section header table: %d\n", *((int *) (a + 32)));
    printf("5. Number of entries in the section header table is: %d \n", *((short *) (a + 48)));
    printf("6. Size of a section header table entry is: %d \n", *((short *) (a + 46)));
    printf("7. offset of the program table is: %d \n", *((int *) (a + 28)));
    printf("8. Number of entries in the program header table is: %d \n", *((short *) (a + 44)));
    printf("9. Size of a section program table entry is: %d \n", *((short *) (a + 42)));
}

void printSectionNames() {
    if (currentFD == -1) {
        printf("There is no file");
        return;
    }
    Elf32_Ehdr *ehdr = (Elf32_Ehdr *) map;
    int numberOfHeaders = ehdr->e_shnum;
    int offset = ehdr->e_shoff;
    Elf32_Shdr *shdr = (Elf32_Shdr *) (map + offset);
    char *stPointer = (char *) (map + shdr[ehdr->e_shstrndx].sh_offset);
    printf("There are %d section headers, starting at offset %#x:\n", numberOfHeaders, offset);
    printf("\nSection Headers:\n");
    printf("[NR] Name                 Addr     Off    Size   Type\n");
    for (int index = 0; index < numberOfHeaders; index++) {
        char *name = stPointer + shdr[index].sh_name;
        printf("[%2d] %-20s %08x %06x %06x %#x\n", index, name,
               shdr[index].sh_addr, shdr[index].sh_offset,
               shdr[index].sh_size, shdr[index].sh_type);
    }
}

void quit() {
    if (debug_mode == 1)
        printf("quitting\n");
    if (map != NULL)
        munmap(map, lseek(currentFD, 0, SEEK_END));
    if (currentFD != -1)
        close(currentFD);
    exit(0);
}

void PrintSymbols(){
    if(currentFD==-1){
        printf("No File Error");
        return;
    }
    Elf32_Ehdr* ehdr=(Elf32_Ehdr*)map;
    int numberOfHeaders=ehdr->e_shnum;
    int offset=ehdr->e_shoff;
    Elf32_Shdr* shdr= (Elf32_Shdr*)(map + offset);
    char* shstPointer=(char*)(map+shdr[ehdr->e_shstrndx].sh_offset);
    for(int index=0;index<numberOfHeaders;index++){
        int stEntry=(int)(shdr[index].sh_link);
        char* stPointer=(char*)(map+shdr[stEntry].sh_offset);
        if(shdr[index].sh_type==SHT_SYMTAB||shdr[index].sh_type==SHT_DYNSYM){
            if(shdr[index].sh_type==SHT_SYMTAB)
                printf("Symbol table '.dynsym' contains %d entries\n",shdr[index].sh_size/shdr[index].sh_entsize);
            else
                printf("Symbol table '.symtab' contains %d entries\n",shdr[index].sh_size/shdr[index].sh_entsize);

            printf("[NR] Value\tNdx      SectionName     \tSymbolName\n");
            Elf32_Sym* symtab1 = (Elf32_Sym*)(shdr[index].sh_offset+(char*)map);
            for(int j=0;j<shdr[index].sh_size/shdr[index].sh_entsize;j++){
                //char* name=stPointer+shdr[index].sh_name;
                char* sectionName;
                if(symtab1[j].st_shndx==0)
                   sectionName ="UND";
                else if(symtab1[j].st_shndx==65521)
                    sectionName ="ABS";
                else if(symtab1[j].st_shndx<numberOfHeaders)
                    sectionName = shstPointer+shdr[symtab1[j].st_shndx].sh_name;
                else
                    sectionName = "COM";

                char* symbolName = stPointer+symtab1[j].st_name;
                printf("[%2d] %08x\t%-6d\t %-18s\t %s\n",j ,
                       symtab1[j].st_value, symtab1[j].st_shndx,
                       sectionName,symbolName);
            }
        }
    }
}

Elf32_Sym* get_dynsym(){
    if (currentFD == -1) {
        printf("No File Error");
        return NULL;
    }
    Elf32_Ehdr *ehdr = (Elf32_Ehdr *) map;
    int numberOfHeaders = ehdr->e_shnum;
    int offset = ehdr->e_shoff;
    Elf32_Shdr *shdr = (Elf32_Shdr *) (map + offset);
    for (int index = 0; index < numberOfHeaders; index++) {
        if(shdr[index].sh_type == SHT_DYNSYM )
            return (Elf32_Sym *)(shdr[index].sh_offset + (char *) map);
    }
   return NULL;
}

int get_dynsymindex(){
    if (currentFD == -1) {
        printf("No File Error");
        return -1;
    }
    Elf32_Ehdr *ehdr = (Elf32_Ehdr *) map;
    int numberOfHeaders = ehdr->e_shnum;
    int offset = ehdr->e_shoff;
    Elf32_Shdr *shdr = (Elf32_Shdr *) (map + offset);
    for (int index = 0; index < numberOfHeaders; index++) {
        if(shdr[index].sh_type == SHT_DYNSYM )
            return index;
    }
    return -1;
}

void RelocationTable() {
    if (currentFD == -1) {
        printf("No File Error");
        return;
    }
    Elf32_Ehdr *ehdr = (Elf32_Ehdr *) map;
    int offset = ehdr->e_shoff;
    Elf32_Shdr *shdr = (Elf32_Shdr *) (map + offset);
    int numberOfHeaders = ehdr->e_shnum;
    char *shstPointer = (char *) (map + shdr[ehdr->e_shstrndx].sh_offset);
    for (int index = 0; index < numberOfHeaders; index++) {
        if (shdr[index].sh_type == SHT_REL) {
            Elf32_Rel *relTab1 = (Elf32_Rel *) (shdr[index].sh_offset + (char *) map);
            int stEntry = (int) (shdr[get_dynsymindex()].sh_link);
            if(stEntry==-1){
                printf("Error");
                return;
            }
            char *stPointer = (char *) (map + shdr[stEntry].sh_offset);
            printf(" Relocation section '%s' at offset %#x contains %d entries:\n",(char*)(shstPointer+shdr[index].sh_name),shdr[index].sh_offset,shdr[index].sh_size / shdr[index].sh_entsize);
            printf("Offset\t\tInfo\t\tType\t\tSym.value\t\tSym.name\n");
            for (int j = 0; j < shdr[index].sh_size / shdr[index].sh_entsize; j++) {
               int dynindex= ELF32_R_SYM((relTab1+j)->r_info);
               Elf32_Sym * dynsymbtable = get_dynsym();
               if(dynsymbtable==NULL){
                   printf("Dynsym return is null, UNEXPECTED\n");
                   return;
               }
                char *symbolName = stPointer +dynsymbtable[dynindex].st_name;
                printf("%08x\t%08d\t%-8d\t%08d\t\t%s\n",(relTab1+j)->r_offset,(relTab1+j)->r_info,
                       ELF32_R_TYPE((relTab1+j)->r_info),dynsymbtable[dynindex].st_value,symbolName);
            }
        }
    }
}

struct fun_desc menu[] =
        {{"Toggle Debug Mode",   toogleDebugMode},
         {"Examine ELF File",    examineELFFile},
         {"Print Section Names", printSectionNames},
         {"Print Symbols",       PrintSymbols},
         {"Relocation Tables",RelocationTable},
         {"Quit",                quit},
         {NULL, NULL}};


int main(int argc, char **argv) {
    debug_mode = 0;
    currentFD = -1;
    int i;
    int option = 0;
    int bound = (sizeof(menu) / sizeof(menu[0])) - 1;
    while (1) {
        i = 0;
        printf("Please choose a function:\n");
        while (menu[i].name) {
            printf("%d) %s\n", i + 1, menu[i].name);
            i++;
        }
        fseek(stdin, 0, SEEK_END);//for clean the buffer
        printf("Option: ");
        scanf("%d", &option);
        if (option >= 1 && option <= bound)
            printf("Within bounds\n");
        else {
            printf("Not within bounds\n");
            quit();
        }
        fgetc(stdin);
        menu[option - 1].fun();
    }
}
