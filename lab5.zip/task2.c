#include <stdio.h>
#include <unistd.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUF_SIZE 2048
#define TERMINATED -1
#define RUNNING 1
#define SUSPENDED 0
#define W_CONTINUED 8
int debugMode = 0;

typedef struct process
{
    cmdLine *cmd;         /* the parsed command line*/
    pid_t pid;            /* the process id that is running the command*/
    int status;           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next; /* next process in chain */
} process;
process **process_list;

/* Free the memory allocated by the list. */
void freeProcessList(process *process_list)
{
    process *temp = process_list;
    while (temp != NULL && temp->cmd != NULL)
    {
        freeCmdLines(temp->cmd);
        temp = temp->next;
    }
    temp = process_list;
    while (temp != NULL)
    {
        temp = temp->next;
        free(process_list);
        process_list = temp;
    }
}

void updateProcessStatus(process *process_list, int pid, int status)
{

    process *temp = process_list;
    while (temp != NULL)
    {
        if (temp->pid == (pid_t)pid)
        {
            temp->status = status;
            break;
        }
        temp = temp->next;
    }
}

void updateProcessList(process **process_list)
{
    process *temp = *process_list;
    int result = 0;
    int status = 0;
    while (temp != NULL)
    {
        result = waitpid(temp->pid, &status, WNOHANG | WUNTRACED | W_CONTINUED);
        if (result == -1 || WIFSIGNALED(status))
            updateProcessStatus(*process_list, temp->pid, TERMINATED);
        else if (WIFSTOPPED(status))
            updateProcessStatus(*process_list, temp->pid, SUSPENDED);
        else if (WIFCONTINUED(status))
            updateProcessStatus(*process_list, temp->pid, RUNNING);
        status = 0;
        temp = temp->next;
    }
}

void addProcess(process **process_list, cmdLine *cmd, pid_t pid)
{
    process *toadd;
    toadd = (process *)(calloc(1, sizeof(process)));
    toadd->cmd = cmd;
    toadd->pid = pid;
    toadd->status = RUNNING;
    toadd->next = NULL;
    if ((*process_list) == NULL)
        (*process_list) = toadd;
    else
    {
        toadd->next = (*process_list);
        (*process_list) = toadd;
    }
}

void deleteProcess(pid_t pid)
{
    process *temp = *process_list;
    process *last = NULL;
    while (temp != NULL)
    {
        if (temp->pid == pid)
        {
            if (last == NULL)
                *process_list = temp->next;
            else
                last->next = temp->next;
            freeCmdLines(temp->cmd);
            free(temp);
            return;
        }
        last = temp;
        temp = temp->next;
    }
}
void printProcessList(process **process_list)
{
    updateProcessList(process_list);
    process *temp = *process_list;
    process *toDelete;
    while (temp != NULL)
    {
        printf("pid\tstatus\tcommand\n");
        printf("%d\t%d\t%s\n", temp->pid, temp->status, temp->cmd->arguments[0]);
        if (temp->status == -1)
        {
            toDelete = temp;
            temp = toDelete->next;
            deleteProcess(toDelete->pid);
        }
        else
            temp = temp->next;
    }
}

void execute(cmdLine *pCmdLine)
{
    int result = 0;
    int pid = fork();
    if (pid == 0)
    {
        result = execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        if (result == -1)
            perror("exec");
        exit(10);
    }
    else
    {
        if (debugMode)
            fprintf(stderr, "PID: %d\ncommand: %s\n", pid, pCmdLine->arguments[0]);
        if (pCmdLine->blocking != 0)
            waitpid(pid, NULL, 0);
        addProcess(process_list, pCmdLine, pid);
    }
}
char* concat(const char *s1, const char *s2)
{
    char *result = malloc(strlen(s1) + strlen(s2) + 1); 
    memcpy(result, s1, strlen(s1));
    memcpy(result + strlen(s1), s2, strlen(s2) + 1); 
    return result;
}
int stringtoint(char *input)
{
    int output = 0;
    int i = 0;
    for (i = 0; i < strlen(input); i++)
    {
        output = output * 10;
        if (input[i] > '9' || input[i] < '0')
        {
            fprintf(stderr, "input is not of type <command> <pid>");
            return -1;
        }
        output += input[i] - '0';
    }
    return output;
}
void killcommand(int command, pid_t pid)
{
    int result;
    result = kill(pid, command);
    if (result == -1)
    {
        perror("kill error");
    }
    else
    {
        printf("the command : %d has executed properly\n", command);
    }
}
int main(int argc, char **argv)
{
    int commandpid = 0;
    char inputbuf[BUF_SIZE];
    char pathbuf[PATH_MAX];
    char *s;
    process_list = (process **)calloc(1, sizeof(process));

    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-d") == 0)
            debugMode = 1;
    }

    while (1)
    {
        getcwd(pathbuf, PATH_MAX);
        s = pathbuf;
        printf("%s$ ", pathbuf);
        fgets(inputbuf, BUF_SIZE, stdin);
        if (strcmp(inputbuf, "quit\n") == 0){
            freeProcessList(*process_list);
            free(process_list);
            break;
        }
        else if (strncmp(inputbuf, "cd ", 3) == 0)
        {
            char *temp = s;
            temp = concat(temp, "/");
            temp = concat(temp, &inputbuf[3]);
            temp[strlen(temp) - 1] = 0;
            int result = chdir(temp);
            if (result == 0)
                s = temp;
            else
                perror("cd");
        }
        else if (strcmp(inputbuf, "procs\n") == 0)
        {
            printProcessList(process_list);
        }
        else if (strncmp("kill ", inputbuf, 5) == 0)
        {
            inputbuf[strlen(inputbuf) - 1] = 0;
            commandpid = stringtoint(&inputbuf[5]);
            killcommand(SIGINT, (pid_t)commandpid);
        }
        else if (strncmp(inputbuf, "suspend ", 8) == 0)
        {
            inputbuf[strlen(inputbuf) - 1] = 0;
            commandpid = stringtoint(&inputbuf[8]);
            killcommand(SIGTSTP, (pid_t)commandpid);
        }
        else if (strncmp(inputbuf, "wake ", 5) == 0)
        {
            inputbuf[strlen(inputbuf) - 1] = 0;
            commandpid = stringtoint(&inputbuf[5]);
            killcommand(SIGCONT, (pid_t)commandpid);
        }

        else
            execute(parseCmdLines(inputbuf));
    }
}