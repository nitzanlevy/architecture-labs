#include <stdio.h>
#include <unistd.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUF_SIZE 2048
int debugMode=0;

void execute(cmdLine *pCmdLine)
{
    int result = 0;
    int pid = fork();
    if (pid == 0)
    {
        result = execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        if (result == -1)
            perror("exec");
        exit(10);
    }
    else
    {
        if (debugMode)
            fprintf(stderr, "PID: %d\ncommand: %s\n", pid, pCmdLine->arguments[0]);
        if (pCmdLine->blocking != 0)
            waitpid(pid, NULL, 0);
    }
}
char* concat(const char *s1, const char *s2)
{
    char *result = malloc(strlen(s1) + strlen(s2) + 1); 
    memcpy(result, s1, strlen(s1));
    memcpy(result + strlen(s1), s2, strlen(s2) + 1); 
    return result;
}
int main(int argc, char **argv)
{
    char inputbuf[BUF_SIZE];
    char pathbuf[PATH_MAX];
    char *s;

    for(int i=1;i<argc;i++){
		if(strcmp(argv[i],"-d")==0)
			debugMode=1;
	}

    while (1)
    {
        getcwd(pathbuf, PATH_MAX);
        s=pathbuf;
        printf("%s$ ", pathbuf);
        fgets(inputbuf, BUF_SIZE, stdin);
        if (strcmp(inputbuf, "quit\n") == 0)
            break;
        else if(strncmp(inputbuf,"cd ",3)==0){  
            char *temp=s;
            temp= concat(temp,"/");
            temp=concat(temp,&inputbuf[3]);
            temp[strlen(temp)-1]=0;
            int result=chdir(temp);
            if(result==0)
                s=temp;
            else
                perror("cd");
        }
        else
            execute(parseCmdLines(inputbuf));
    }
}