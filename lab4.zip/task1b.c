#include "util.h"

#define SYS_READ 3
#define SYS_WRITE 4
#define STDERR 1
#define SYS_OPEN 5
#define O_RDONLY 0
#define O_CREATE 100
#define O_WDONLY 1
#define SYS_CLOSE 6
#define STDOUT 1
#define STDIN 0

extern int system_call();


void my_printf(int print_to, int size){
	char ch[]={*itoa(print_to), '\t', 0};
	system_call(SYS_WRITE,STDERR,ch,strlen(ch));
	char *ch2=itoa(size);
	system_call(SYS_WRITE,STDERR,ch2,strlen(ch2));
	system_call(SYS_WRITE,STDERR,"\n",1);
}


int main (int argc , char* argv[], char* envp[])
{
	char buffer[100];
	int i;

	int debugMode=0,outputMode=0,inputMode=0;

	int input=0,counter=0,size=0,indexOfOutput=0,indexOfInput=0;
	
	int inputFile=STDIN, outputFile=STDOUT;
	
	for(i=1;i<argc;i++){
		if(strcmp(argv[i],"-D")==0)
			debugMode=1;
		else if(strncmp(argv[i],"-o",2)==0)
		{
			indexOfOutput=i;
			outputMode=1;
		}
		else if(strncmp(argv[i],"-i",2)==0)
		{
			indexOfInput=i;
			inputMode=1;
		}
	}
    if(inputMode)
	{
		inputFile = system_call(SYS_OPEN,(argv[indexOfInput]+2),O_RDONLY,0777);
		if(debugMode) my_printf(SYS_OPEN,inputFile);
	}
	if(outputMode)
	{
		outputFile = system_call(SYS_OPEN,(argv[indexOfOutput]+2),(O_CREATE+O_WDONLY),0777);
		if(debugMode) my_printf(SYS_OPEN,outputFile);
	}
	size=system_call(SYS_READ,inputFile,buffer,100);
	if(debugMode)
		my_printf(SYS_READ,size);
	while(counter<size)
	{
		input=buffer[counter];
		if(input>='a' && input<='z')
			input-='a'-'A';
		if(debugMode){
			if(input==10){
				system_call(SYS_WRITE,STDERR,"\n",1);
			}
			else{
				char ch[]={buffer[counter], '\t' , input ,'\n'};
				system_call(SYS_WRITE,STDERR,ch,4);
			}
		}
		buffer[counter]=input;
		counter++;
	}
	size=system_call(SYS_WRITE,outputFile,buffer,strlen(buffer));
	if(debugMode)
		my_printf(SYS_WRITE,size);
	if(inputMode){
		system_call(SYS_CLOSE,inputFile);
		if(debugMode)
			my_printf(SYS_CLOSE,inputFile);
	}
	if(outputMode){
		system_call(SYS_CLOSE,outputFile);
		if(debugMode)
			my_printf(SYS_CLOSE,outputFile);
	}
	return 0;	
}


