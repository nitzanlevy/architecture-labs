//
// Created by ofek on 14/05/2020.
//
#include <stdio.h>
#include <unistd.h>
#include <linux/limits.h>
#include "LineParser.h" //might be needed to change
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>

#define BUF_SIZE 2048
int debugMode = 0;

char *concat(const char *s1, const char *s2) {
    char *result = (char *) malloc(strlen(s1) + strlen(s2) + 1);
    memcpy(result, s1, strlen(s1));
    memcpy(result + strlen(s1), s2, strlen(s2) + 1);
    return result;
}

void execute(cmdLine *pCmdLine) {
    int result = 0;
    printf("%s\n",pCmdLine->inputRedirect);
    printf("%s\n",pCmdLine->outputRedirect);
    int pid = fork();
    if (pid == 0) {
        if (pCmdLine->inputRedirect != NULL) {
            fclose(stdin);
            if (open(pCmdLine->inputRedirect, O_RDWR) == -1)
                perror("output redirect");
        }
        if (pCmdLine->outputRedirect != NULL) {
            fclose(stdout);
            if (open(pCmdLine->outputRedirect,O_RDWR) == -1)
                perror("output redirect");
        }
        result = execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        if (result == -1)
            perror("exec");
        exit(10);
    } else {
        if (debugMode)
            fprintf(stderr, "PID: %d\ncommand: %s\n", pid, pCmdLine->arguments[0]);
        if (pCmdLine->blocking != 0)
            waitpid(pid, NULL, 0);
    }
}

int main(int argc, char **argv) {
    char inputbuf[BUF_SIZE];
    char pathbuf[PATH_MAX];
    char *s;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0)
            debugMode = 1;
    }

    while (1) {
        getcwd(pathbuf, PATH_MAX);
        s = pathbuf;
        printf("%s$ ", pathbuf);
        fgets(inputbuf, BUF_SIZE, stdin);
        cmdLine* cmdLine=parseCmdLines(inputbuf);
        if (strcmp(cmdLine->arguments[0], "quit") == 0)
            break;
        else if (strcmp(cmdLine->arguments[0], "cd") == 0) {
            char *dir;
                dir = s;
                dir = concat(dir, "/");
                dir = concat(dir, cmdLine->arguments[1]);
            int result = chdir(dir);
            if (result == 0)
                s = dir;
            else
                perror("cd");
        } 
        else
            execute(cmdLine);
    }
}
