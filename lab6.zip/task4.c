
#include <stdio.h>
#include <unistd.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>

#define BUF_SIZE 2048
int debugMode = 0;
typedef struct node {
    char *name;
    char *value;
    struct node *next;
} node;
node *variable_ll;

/* Free the memory allocated by the list. */
void freeList()
{
    node *temp = variable_ll;
    while (temp != NULL )
    {
        free(temp->name);
        free(temp->value);
        temp = temp->next;
    }
    temp = variable_ll;
    while (temp != NULL)
    {
        temp = temp->next;
        free(variable_ll);
        variable_ll = temp;
    }
}

void add_first(char *name, char *value) {
    if (variable_ll == NULL) {
        variable_ll = calloc(1,sizeof(node));
        variable_ll->name=calloc(1, sizeof(char*));
        variable_ll->value=calloc(1, sizeof(char*));
        variable_ll->next=NULL;
        int len = sizeof(name);
        memcpy(variable_ll->name, name, len);
        len=sizeof(value);
        memcpy(variable_ll->value, value,len);
    } else {
        node *nextone =calloc(1,sizeof(node));
        nextone->name=calloc(1, sizeof(char*));
        nextone->value=calloc(1, sizeof(char*));
        int len=sizeof(name);
        memcpy(nextone->name, name, len);
        len=sizeof(value);
        memcpy(nextone->value, value,len);
        nextone->next = variable_ll;
        variable_ll = nextone;
    }
}

char *concat(const char *s1, const char *s2) {
    char *result = (char *) malloc(strlen(s1) + strlen(s2) + 1);
    memcpy(result, s1, strlen(s1));
    memcpy(result + strlen(s1), s2, strlen(s2) + 1);
    return result;
}


void execute(cmdLine *pCmdLine) {

    int result = 0;
    int pipestruct[2];
    if(pipe(pipestruct)==-1)
        perror("pipe");
    int pid = fork();
    if (pid == 0) {
        if(pCmdLine->next!=NULL)
        {
            close(STDOUT_FILENO);
            dup(pipestruct[1]);
            close(pipestruct[1]);
        }
        if (pCmdLine->inputRedirect != NULL) {
            fclose(stdin);
            if (open(pCmdLine->inputRedirect, O_RDWR) == -1)
                perror("output redirect");
        }
        if (pCmdLine->outputRedirect != NULL) {
            fclose(stdout);
            if (open(pCmdLine->outputRedirect, O_CREAT | O_RDWR) == -1)
                perror("output redirect");
        }
        result = execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        if (result == -1)
            perror("exec");
        exit(10);
    } else {
        close(pipestruct[1]);
        if(pCmdLine->next!=NULL){
            int childpid=fork();
            if (childpid == 0) {
                close(STDIN_FILENO);
                dup(pipestruct[0]);
                close(pipestruct[0]);
                if (execvp(pCmdLine->next->arguments[0],pCmdLine->next->arguments) == -1)
                    perror("exec failed");
            }
            else{
                close(pipestruct[0]);
                int status = 0;
                int result = 0;
                result = waitpid(childpid, &status, 0);
                if (result == -1)
                    fprintf(stderr, "error with first child wait operation\n");
            }
        }
        if (debugMode)
            fprintf(stderr, "PID: %d\ncommand: %s\n", pid, pCmdLine->arguments[0]);
        if (pCmdLine->blocking != 0)
            waitpid(pid, NULL, 0);
    }
}

char* findvariable(char* name){
    node* temp = variable_ll;
    while(temp!=NULL){
        if(strcmp(name,temp->name)==0)
            return temp->value;
        temp=temp->next;
    }
    return NULL;
}

char *substring(char *string, int position, int length)
{
    char *pointer=  calloc(1,length+1);
    int i;
    for ( i = 0 ; i < length ; i++)
    {
        *(pointer+i) = *(string+position-1);
        string++;
    }
    *(pointer+i) = 0;
    return pointer;
}

int main(int argc, char **argv) {
    char inputbuf[BUF_SIZE];
    char pathbuf[PATH_MAX];
    char *s;
    cmdLine* temp;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0)
            debugMode = 1;
    }
    cmdLine* cmdLine1;
    while (1) {
        getcwd(pathbuf, PATH_MAX);
        s = pathbuf;
        printf("%s$ ", pathbuf);
        fgets(inputbuf, BUF_SIZE, stdin);
        cmdLine1=parseCmdLines(inputbuf);
        temp=cmdLine1;
        char* newString;
        char* temp2;
        //loop over the arguments and replace them with their symbols
        while(temp) {
            for (int i = 0; i < temp->argCount; i++) {
                newString = temp->arguments[i];
                if (strncmp(newString, "$", 1) == 0) {
                    temp2 = substring(newString, 2, strlen(newString));
                    newString = findvariable(temp2);
                    replaceCmdArg(temp, i, newString);
                    free(temp2);
                }
            }
            temp=temp->next;
        }

        if (strcmp(cmdLine1->arguments[0], "quit") == 0){
            freeCmdLines(cmdLine1);
            freeList();
            break;
        }
        else if (strcmp(cmdLine1->arguments[0], "cd") == 0) {
            char *dir;
            if(strcmp(cmdLine1->arguments[1],"~")==0) {
                dir = getenv("HOME");
            }
            else {
                dir = s;
                dir = concat(dir, "/");
                dir = concat(dir, cmdLine1->arguments[1]);
            }
            int result = chdir(dir);
            if (result == 0)
                s = dir;
            else
                perror("cd");
        } else if (strcmp(cmdLine1->arguments[0], "set") == 0) {
            char *name = strtok(&inputbuf[4], " ");
            char *value = strtok(&inputbuf[4 + strlen(name) + 1], "\n");
            add_first(name,value);
        }
        else if(strcmp(cmdLine1->arguments[0], "vars") == 0) {
            node *temp3 = variable_ll;
            while (temp3){
                printf("Name:%s\nValue:%s\n", temp3->name, temp3->value);
                temp3=temp3->next;
            }
        }
        else
            execute(cmdLine1);
        freeCmdLines(cmdLine1);
    }
}
