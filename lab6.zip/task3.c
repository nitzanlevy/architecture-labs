//
// Created by ofek on 15/05/2020.
//
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>


int main(int argc, char **argv) {
    int pipestruct[2];
    int pipenum;
    int debugmode = 0;
    int i = 0;
    for (i = 0; i < argc; i++) {
        if (strcmp("-d", argv[i]) == 0) {
            debugmode = 1;
        }
    }
    pipenum = pipe(pipestruct);
    if (pipenum == -1) {
        perror("pipe error");
    }
    // create a pipe - done

    int firstpid=0;
    int secondpid=0;
    if (debugmode == 1) {
        fprintf(stderr, "(<parent process> forking..)\n");
    }
    firstpid = fork();
    if (firstpid == 0){
        if(debugmode==1){
            fprintf(stderr,"(child1>redirecting stdout to the write end of the pipe…)\n");
            fprintf(stderr,"(child1>going to execute cmd: …)\n");
        }
        close(STDOUT_FILENO);
        dup(pipestruct[1]);
        close(pipestruct[1]);
        char *a[] = {"ls", "-l",0};
        if (execvp(a[0], a) == -1)
            perror("exec failed");
    }
    else
    {
        if (debugmode == 1) {
            fprintf(stderr, "(<parent process> created process with id:%d )\n", firstpid);
            fprintf(stderr, "(parent_process>closing the read end of the pipe, number: %d)\n", pipestruct[1]);
        }
        close(pipestruct[1]);
        if (debugmode == 1)
            fprintf(stderr, "(<parent process> forking..)\n");
        secondpid = fork();
        if (secondpid == 0) {
            if(debugmode==1){
                fprintf(stderr,"(child2>redirecting stdout to the write end of the pipe, number: %d)\n",pipestruct[0]);
                fprintf(stderr,"(child2>going to execute cmd: …)\n");
            }
            close(STDIN_FILENO);
            dup(pipestruct[0]);
            close(pipestruct[0]);
            char* b[]={"tail","-n","2",0};
            if (execvp(b[0],b) == -1)
                perror("exec failed");
        }
        else
        {
            if (debugmode == 1) {
                fprintf(stderr, "(<parent process> created process with id:%d )\n", secondpid);
                fprintf(stderr, "(parent_process>closing the read end of the pipe…)\n");
            }
            close(pipestruct[0]);
            int status = 0;
            int result = 0;
            if (debugmode)
                fprintf(stderr, "(parent_process>waiting for first child processes to terminate…)\n");
            result = waitpid(firstpid, &status, 0);
            if (result == -1)
                fprintf(stderr, "error with first child wait operation\n");
            if (debugmode)
                fprintf(stderr, "(parent_process>waiting for first child processes to terminate…)\n");
            result = waitpid(secondpid, &status, 0);
            if (result == -1)
                fprintf(stderr, "error with second child wait operation\n");
            fprintf(stderr,"Parent process exiting\n");
        }
    }
}
