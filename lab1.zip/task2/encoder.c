#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	int input=0,original=0,len=0,carry=0,index=0;
	//All the modes in the program
	int debugMode=0,encryMode=0,encryPlus=0,outputMode=0,inputMode=0;
	//index per mode
	int indexOfEncry=0,indexOfOutput=0,indexOfInput=0;
	int * encryKey;
	FILE *output;
	FILE *inputFile;
	for(int i=1; i<argc; i++)
    {
        if(strcmp(argv[i],"-D")==0)
       		debugMode=1;
       	else if(argv[i][0]=='+' && argv[i][1]=='e')
        {
            indexOfEncry=i;
            encryMode=1;
            encryPlus=1;
        }
        else if(argv[i][0]=='-' && argv[i][1]=='e')
        {
            indexOfEncry=i;
            encryMode=1;
            encryPlus=0;
        }
        else if(argv[i][0]=='-' && argv[i][1]=='o')
        {
            indexOfOutput=i;
            outputMode=1;
        }
        else if(argv[i][0]=='-' && argv[i][1]=='i')
        {
            indexOfInput=i;
            inputMode=1;
        }
    }
    if(outputMode==1)
    {
		int lenOut=strlen(argv[indexOfOutput])-2;
		char *fileName=(char*)malloc(lenOut*sizeof(char));
		for(int j=0;j<lenOut;j++)
        	    fileName[j] = (argv[indexOfOutput][j+2] );
		output=fopen(fileName,"w");
		if(!output)
			fprintf(stderr,"Error:the file cannot open");
	}
	else output=stdout;
    if(inputMode==1)
    {
        int lenIn=strlen(argv[indexOfInput])-2;
        char * inFileName=(char*)malloc(lenIn*sizeof(char));
        for(int j=0;j<lenIn;j++)
            inFileName[j] = (argv[indexOfInput][j+2]);
        inputFile = fopen(inFileName, "r");
        if(inputFile)
            stdin=inputFile;
        else
            fprintf(stderr,"ERROR: there is no file with this name");
    }
	if(encryMode==1)
    	{
        	len=strlen(argv[indexOfEncry])-2;
		encryKey=(int*)malloc(len*sizeof(int));
        	for(int j=0;j<len;j++)
        	    encryKey[j] = (argv[indexOfEncry][j+2] );
    	}
	while((input=fgetc(stdin))!= EOF)
	{
		original=input;
		if(encryMode==0 &&input<91 && input>64)
			input+=32;
		if(input==10)
			index=0;
		else if(encryMode==1 && input!=32)
		{	
			int outI;
			int adding=0;
			carry=index%len;
			adding=encryKey[carry]-64;
			if(encryPlus==1)
				outI=(adding+input)%128;
			else{
				outI=(adding-input)%128;	
				if(outI<0)
					outI=outI*(-1);
			}	
			input=outI;
			index=index+1;
		}
		if(debugMode==1)
		{
			if(input==10)
				fprintf(stderr,"\n");
			else
				fprintf(stderr, "%d\t%d\n", original, input);
		}
		fprintf(output,"%c", input);
	}
	return 0;
}



